<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Создать поездку</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('trips.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Откуда</label>
            <input type="text" name="from_city" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Куда</label>
            <input type="text" name="to_city" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Дата</label>
            <input type="date" name="date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Время</label>
            <input type="time" name="time" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Доступные места</label>
            <input type="number" name="seats" min="1" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Цена за место (₽)</label>
            <input type="number" name="price" min="0" step="0.01" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Комментарий (необязательно)</label>
            <textarea name="note" class="form-control" rows="3"></textarea>
        </div>

        <button class="btn btn-success">Создать поездку</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/trips/create.blade.php ENDPATH**/ ?>