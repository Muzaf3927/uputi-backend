<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1>Добро пожаловать в BlaBlaCar MVP</h1>
        <?php if(auth()->guard()->guest()): ?>
            <a href="/login" class="btn btn-primary mt-3">Войти</a>
            <a href="/register" class="btn btn-outline-primary mt-3">Регистрация</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/welcome.blade.php ENDPATH**/ ?>